---
name: Pohang Explorer
colors:
  surface: '#f9f9ff'
  surface-dim: '#cddaf8'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e8eeff'
  surface-container-high: '#dfe8ff'
  surface-container-highest: '#d6e3ff'
  on-surface: '#0e1c31'
  on-surface-variant: '#434750'
  inverse-surface: '#243147'
  inverse-on-surface: '#ecf0ff'
  outline: '#747781'
  outline-variant: '#c3c6d1'
  surface-tint: '#3c5e98'
  primary: '#002553'
  on-primary: '#ffffff'
  primary-container: '#123b73'
  on-primary-container: '#85a7e6'
  inverse-primary: '#abc7ff'
  secondary: '#005db7'
  on-secondary: '#ffffff'
  secondary-container: '#619efd'
  on-secondary-container: '#00346c'
  tertiary: '#481700'
  on-tertiary: '#ffffff'
  tertiary-container: '#6b2600'
  on-tertiary-container: '#fb8751'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d7e3ff'
  primary-fixed-dim: '#abc7ff'
  on-primary-fixed: '#001b3f'
  on-primary-fixed-variant: '#21467f'
  secondary-fixed: '#d6e3ff'
  secondary-fixed-dim: '#a9c7ff'
  on-secondary-fixed: '#001b3e'
  on-secondary-fixed-variant: '#00468c'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#f9f9ff'
  on-background: '#0e1c31'
  surface-variant: '#d6e3ff'
  sky-bg: '#eaf3ff'
  muted-blue: '#6e7d92'
  border-line: '#dce6f2'
  page-bg: '#f6f9fd'
  surface-white: '#ffffff'
  status-gold: '#855d1f'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 38px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '800'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Inter
    fontSize: 21px
    fontWeight: '700'
    lineHeight: '1.4'
  brand-title:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '900'
    lineHeight: '1.0'
  section-title:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.7'
  body-default:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: '1.55'
  label-bold:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '800'
    lineHeight: '1.0'
  eyebrow:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '800'
    lineHeight: '1.0'
    letterSpacing: 0.05em
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.7'
  tiny-tag:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: '1.0'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  page-max-width: 1440px
  sidebar-width: 360px
  topbar-height: 74px
  margin-desktop: 28px
  margin-mobile: 16px
  gutter-grid: 22px
  padding-card: 18px
  gap-itinerary: 14px
  gap-component-stack: 10px
  gap-chip-group: 8px
---

## Brand & Style

This design system is crafted for a premium travel recommendation service, blending professional reliability with a vibrant, exploratory spirit. The visual narrative is inspired by the coastal geography of Pohang—merging deep oceanic depths with the energetic warmth of a seaside sunset.

The style is **Modern Corporate with Glassmorphism accents**. It prioritizes high-fidelity utility through clean layouts, but introduces depth and "breeze" via translucent layers and soft, tinted blurs. The aesthetic should feel organized enough for efficient itinerary planning yet light enough to evoke the joy of a vacation. 

Key attributes:
- **Professional & Trustworthy:** Using structured grids and a primary navy palette.
- **Vibrant & Exploratory:** Highlighting moments with sunset orange and bright coastal blues.
- **Atmospheric:** Utilizing glassmorphism and blue-tinted shadows to mimic the clarity of coastal air.

## Colors

The palette is anchored by a "Deep Ocean" navy which serves as the primary driver for actions and brand identity. This is supported by a "Coastal Blue" for interactive elements and a "Sunset Accent" orange used sparingly for high-priority highlights and specific map markers.

- **Primary (#123b73):** Used for critical actions, navigation headers, and active state indicators.
- **Secondary (#2f74d0):** Used for map interactions, interactive inputs, and secondary branding.
- **Tertiary (#ff8a54):** Used as a surgical accent color to draw attention to specific "hot spots" or warnings.
- **Neutral (#17243a):** High-contrast ink for maximum legibility in body copy.

Backgrounds utilize a very pale blue-grey (`#f6f9fd`) instead of pure white to reduce glare and maintain the coastal theme.

## Typography

The system uses **Inter** for all Latin characters and **Noto Sans KR** for CJK support to ensure a clean, neutral, and highly readable interface. 

The hierarchy is built on extreme weight contrasts rather than just size. Headlines use Heavy/Bold weights (700-900) to stand out against the functional body text. 
- **Display styles** are reserved for hero sections and impact moments.
- **Eyebrow text** should always be uppercase with increased letter spacing to provide clear categorisation.
- **Labels** use a heavy weight (800) at a small size (13px) to create a "UI-heavy" but organized feel, similar to a dashboard.

## Layout & Spacing

The design system employs a **Fixed Grid with Sidebar** model for desktop and a **Fluid Stack** for mobile.

- **Desktop:** A dual-pane layout where the left 360px is dedicated to planning controls and the right fluid area is reserved for the map or itinerary results.
- **Rhythm:** An 8px-based spacing system is used, with 18px and 22px as the primary semantic gaps for layout containers to create a sense of breathability.
- **Breakpoints:**
  - **Desktop (1024px+):** Sidebar is fixed at 360px.
  - **Tablet (768px - 1023px):** Sidebar converts to a collapsible drawer or top-shelf area.
  - **Mobile (Below 768px):** Single column layout with 16px horizontal margins. Map and List views are toggled via a floating action button.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **Blue-Tinted Shadows**. Unlike standard grey shadows, this system uses a soft navy tint (`rgba(31, 75, 126, 0.06)`) to maintain color harmony.

- **Level 1 (Base):** Background surface (`#f6f9fd`).
- **Level 2 (Cards/Panels):** Pure white surfaces with a 28px blur shadow. 
- **Level 3 (Interactive/Glass):** Elements that appear "above" the map use a backdrop-blur (12px-20px) and 70-80% opacity white fill to create a glassmorphic effect.
- **Level 4 (Popovers/Toasts):** High-contrast navy or high-elevation white with crisp borders for immediate attention.

## Shapes

The shape language is **Generously Rounded**, reflecting a friendly and approachable travel vibe. 

- **Primary Containers:** 18px radius for all main cards and panels.
- **Interactive Elements:** Buttons and toast notifications use a slightly tighter 10px-11px radius to feel more "clickable" and distinct from layout containers.
- **Small Components:** Chips and badges use 9px or 6px for a compact, pill-like appearance.
- **The Wave Logo:** Enclosed in a 12px rounded-square gradient box, acting as the visual anchor.

## Components

### Buttons
- **Primary:** Solid `#123b73` fill, white text, 11px radius.
- **Ghost:** Light blue-grey fill (`#f3f7fc`), primary navy text, 10px radius.
- **Icon Buttons:** Circular or 10px rounded squares with subtle borders.

### Cards & Glassmorphism
Cards must have an 18px border radius and a 1px border of `#dce6f2`. For "Floating Cards" (on the map), apply a `backdrop-filter: blur(16px)` with a semi-transparent white background.

### Itinerary Timeline
- **Visual Path:** Use a dashed SVG line (`stroke-dasharray: 3 1`) between stops.
- **Stop Indicators:** Circular badges with secondary blue backgrounds and white numbers.
- **Stop Cards:** Internal padding of 18px, with metadata (time/cost) separated by `#dce6f2` dividers.

### Chips & Filters
- **Default State:** Light grey background (`#f1f5fa`), muted text.
- **Active State:** Primary navy background, white text, 9px radius.

### Input Fields
- Use a 1px border and 10px radius. Labels should be placed above the field in `label-bold` style (13px, 800 weight). Focused states should use a 2px Coastal Blue (`#2f74d0`) border.